function [wpo,spo] = calc_po_chance(md_inf,pan_lvl)
%CALC_PO_CHANCE Summary of this function goes here
%   Detailed explanation goes here
wpo = 0.0001*md_inf;
spo = 0.001*md_inf;
end

