function [wch,sch] = calc_sf_chance(md_inf)
%CALC_SF_CHANCE Summary of this function goes here
%   Detailed explanation goes here
wch = 0.2*md_inf;
sch = 0.1*md_inf;
end

