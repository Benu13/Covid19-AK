clear all;
FUNKY_MODE = 0; %WARNING! EXTREME FUNK LEVELS- SET ON ONE ON YOUR OWN RESPONSIBILITY
%% Country data
population = 10000;
people_older_than_60 = 0.10; % w procentach
smokers_and_other_risk = 0.10;% w procentach
sick = people_older_than_60 + smokers_and_other_risk;
gov_control = 1; %goverment intervention level
inf_camp_lvl = 1; % information campain level
ys =44100;

pop_sq = round(sqrt(population));
pop_mat = zeros(round(sqrt(population)));

%% Basic prob - FROM BS DATA BY JUAN PABLO V2
inf_chance_base = 0.25;
quar_chance_base = 0.25;
deatch_chance_base = 0.25;
prot_chance = 0.25;
prot_o_chance_base = 0.25;
org_prot_chance_base = 0.25;
get_sick_chance = 0.10;
sick_recover_ch = 0.005;


%% Person struct 
p.state = 1;
p.get_inf_ch = inf_chance_base; % infection chance
p.quarantine_chance = quar_chance_base;
p.death_chance = deatch_chance_base;
p.time_since_infected = 0; 
p.prot_ch = prot_chance;
p.prot_o_ch = prot_o_chance_base;
p.org_prot_ch = org_prot_chance_base;
p.get_sick_chance = get_sick_chance;
p.sick_recover_chance = sick_recover_ch;
p.modyficators.no_sec_meas = 0;
p.modyficators.self_protecting = 0;
p.modyficators.protectiong_others = 0;
p.modyficators.organizing_protection = 0;
p.modyficators.was_sick = 0;
p.modyficators.protected_by_others = 0;
p.modyficators.scapegoat = 0;


%% Population array
for i = 1:pop_sq
    for j = 1:pop_sq
        r_temp = rand(1);
        pop_array(i,j) = p;
        if(r_temp)<sick
            pop_array(i,j).state = 7;
        end
    end
end

%% Random first sick person
X = randi(pop_sq);
Y = randi(pop_sq);

pop_array(X,Y).state = 3;
pop_array(X,Y).time_since_infected = 1;

%%
tm = 40;
timespan = 1:1:tm;
inf_gr_sum = [];
x = 1;
hFig = figure('Name','State');
hold on
day = 1;
load('data_af.mat')
           
while day <= tm
    pop_demo = reshape_of_my_heart(pop_array);

    % Data update
    [x,y] = find(pop_demo == 3 | pop_demo == 8); % SEEK THE INFECTED
    pop_array = eu4_time(pop_array);
    [pop_array,FUNKY_MODE,cm,tm] = update_infected(pop_array,x,y,FUNKY_MODE,tm);
    pop_array = Moirai_thread(pop_array,x,y);

    %Drawing part
    colormap(cm)
    subplot(2,2,[1,3])
    imagesc(pop_demo);
    drawnow;
    if FUNKY_MODE == 0 
        subplot(2,2,2)
        inf_gr_sum = [inf_gr_sum length(x')];
        plot(1:day, inf_gr_sum)
    end
    drawnow;
    if FUNKY_MODE == 2
        subplot(2,2,[2,4]);
        rand_temp = rand(1);
        if rand_temp < 0.33
            imshow(ev_t_d)
        end
        if rand_temp >= 0.33 && rand_temp <0.66
            imshow(rgb2ycbcr(ev_t_d));
        end
        if rand_temp >= 0.66
            imshow(rgb2hsv(ev_t_d));
        end
    end
    day = day+1;
end

clear all
% healthy = 1
% In_quarantine = 2
% infected = 3
% In_hospital = 4
% Recovered = 5
% Dead = 6
% sick = 7
% inf_and_sic = 8
