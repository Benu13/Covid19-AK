function [x_ind,y_ind] = get_neighbours(pop_struct,x_inf,y_inf)
%GET_NE Summary of this function goes here
%   Detailed explanation goes here

pop_mat = reshape_of_my_heart(pop_struct);

M = zeros(size(pop_mat));
M(x_inf,y_inf) = 1;
C = conv2(M,[1,1,1;1,0,1;1,1,1],'same')>0;
%C(x_inf,y_inf) = 0;
[x,y] = find(C == 1);
x_ind = x;
y_ind = y;

end

