function [pop_infect_update,FUN,CM,tm,ev] = update_infected(pop_struct,x,y,FM,tl)
%GET_INFECTED Summary of this function goes here
%   Detailed explanation goes here
global FUNK;
pop_struct_s = pop_struct;
inf_index = 3;
inf_index_2 = 8;
[x_neig,y_neig] = get_neighbours(pop_struct,x,y);

if FM == 1
    load('data_af.mat');
    sound(y2,44100);
    FUNK = 1;
end
funk_is_on = 0;
if FUNK == 1
    funk_is_on = 1;
end
for i = 1:length(x')
    pop_struct_s(x(i),y(i)).time_since_infected = pop_struct(x(i),y(i)).time_since_infected + 1;
end

for i = 1:length(x_neig')
    rand_temp = rand(1);
    if (rand_temp < pop_struct(x_neig(i),y_neig(i)).get_inf_ch && ...
            ((pop_struct_s(x_neig(i),y_neig(i)).state == 1 || ...
            pop_struct_s(x_neig(i),y_neig(i)).state == 7)||funk_is_on==1)) 
        
        if pop_struct_s(x_neig(i),y_neig(i)).state == 7
            pop_struct_s(x_neig(i),y_neig(i)).state = 3;
            pop_struct_s(x_neig(i),y_neig(i)).time_since_infected = 1;
            pop_struct_s(x_neig(i),y_neig(i)).modyficators.was_sick = 1;
       
        else
            pop_struct_s(x_neig(i),y_neig(i)).state = 3;
            pop_struct_s(x_neig(i),y_neig(i)).time_since_infected = 1;
        end
        
    end
end
if FUNK == 1
    % Define the two colormaps.
    cmap1 = hot(9);
    cmap2 = winter(9);
    % Combine them into one tall colormap.
    combinedColorMap = [cmap1; cmap2];
    % Pick 15 rows at random.
    randomRows = randi(size(combinedColorMap, 1),[9,1]);
    % Extract the rows from the combined color map.
    randomColors = combinedColorMap(randomRows, :);
    CM = randomColors;
    tm = 23000;
    FUN = 2;
else
    tm=tl;
    CM = winter(9);
    FUN = 0;
end
pop_infect_update = pop_struct_s;
end

