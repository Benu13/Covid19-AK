function [pop_struct_out] = Moirai_thread(pop_struct,x_inf,y_inf)
%MOIRAI_TRIAL Summary of this function goes here
%   Detailed explanation goes here

%CONSTS
incubation_time = 14;
recovery_time = 28;
recovery_time_weak = 35;

pop_struct_s = pop_struct;
for i = 1:length(x_inf') %Kloto
    if pop_struct_s(x_inf(i),y_inf(i)).time_since_infected >= 2 && ...
            pop_struct_s(x_inf(i),y_inf(i)).state ~= 8
        
        rand_temp = rand(1);
        if rand_temp < pop_struct(x_inf(i),y_inf(i)).time_since_infected/incubation_time
            pop_struct_s(x_inf(i),y_inf(i)).state = 8;
            pop_struct(x_inf(i),y_inf(i)).time_since_infected = 1;
        end
    end
end

for i = 1:length(x_inf') %Lachesis
    if pop_struct_s(x_inf(i),y_inf(i)).state == 8
        rand_temp = rand(1);
        calc_prob = 1/(recovery_time-pop_struct(x_inf(i),y_inf(i)).time_since_infected);
        if rand_temp < calc_prob %LAST JUDGMENT
            rand_temp = rand(1);
            if rand_temp < pop_struct(x_inf(i),y_inf(i)).death_chance %Atropos
                pop_struct_s(x_inf(i),y_inf(i)).state = 6;
            else %Atropos
                pop_struct_s(x_inf(i),y_inf(i)).state = 5;
            end
        end
    end
end


pop_struct_out = pop_struct_s;
end

