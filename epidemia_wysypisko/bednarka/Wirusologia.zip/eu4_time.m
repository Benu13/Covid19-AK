function [up_pop_str] = eu4_time(pop_struct)
%UNTILTED8 Summary of this function goes not here
%   Detailed explanation goes home

% CONST
weak_chance_sf = 0.25; %chance for sick people to go self protecting
strong_chance_sf = 0.05; %chance for healthy people to go self protecting
mary_sue = 0.0001; %chance for sick people to go mad
strong_chance_po = 0.005; %chance for healthy people to protect others


pop = pop_struct;
len = length(pop);

pop_demo = [pop(:,:).state];
pop_mods = [pop(:,:).modyficators];
pop_mods = [pop_mods(:,:).was_sick];

pop_mat_d = reshape(pop_demo,len,len);
pop_mat_m = reshape(pop_mods,len,len);

[a,b] = find(pop_mat_d == 7);
[c,d] = find(pop_mat_m == 1);
x=[a;c];
y=[b;d];

% INB4: THERE'S NO CURE FOR OLD AGE
% YET
for i = 1:length(x')
    rand_temp = rand(1);
    if rand_temp < pop(x(i),y(i)).sick_recover_chance
        if pop(x(i),y(i)).state == 7
            pop(x(i),y(i)).state = 1;
        else
            pop(x(i),y(i)).modyficators.was_sick = 0;
        end
    end
end

xx = setdiff(1:len,x);
yy = setdiff(1:len,y);

% EACH MAN FOR HIMSELF
for i = 1:length(a')
    temp_rand = rand(1);
    if temp_rand < weak_chance_sf
         pop(a(i),b(i)).modyficators.self_protecting = 1;
    end
end

for i = 1:length(xx')
    temp_rand = rand(1);
    if temp_rand < strong_chance_sf
         pop(xx(i),xx(i)).modyficators.self_protecting = 1;
    end
end

% HERO TIME
for i = 1:length(a')
    temp_rand = rand(1);
    if temp_rand < mary_sue
         pop(a(i),b(i)).modyficators.protectiong_others = 1;
         [x_ne,y_ne] = get_neighbours(pop,a(i),b(i));
         for j = 1:length(x_ne')
             pop(x_ne(j),y_ne(j)).modyficators.protected_by_others = 1;
         end
    end
end

for i = 1:length(xx')
    temp_rand = rand(1);
    if (temp_rand < strong_chance_po && pop(x_neig(i),y_neig(i)).state == 1 ...
        || pop(x_neig(i),y_neig(i)).state == 5 )
         pop(a(i),b(i)).modyficators.protectiong_others = 1;
         [x_ne,y_ne] = get_neighbours(pop,a(i),b(i));
         for j = 1:length(x_ne')
             pop(x_ne(j),y_ne(j)).modyficators.protected_by_others = 1;
         end
    end
end


up_pop_str = pop;
end


