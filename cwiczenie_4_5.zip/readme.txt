Modele z ćw. 2 znajdują się w folderach LB i PZ.

Model różniczkowy znajduje się w folderze SIR.

Aplikacja nazywa się app1.mlapp i symulacje najlepiej wywoływać z jej poziomu. 

Symulacji PZ nie należy włączać dla dużych populacji (powyżej 10 000).

Sprawozdania z ćw. 2 są pod nazwą spr_LB_SW.pdf, spr_PZ_GB,pdf. Przedstawienie modelu różniczkowego nazywa się rozn.pdf. Pliki z danymi rzeczywistymi są w arkuszach kalkulacyjnych .xlsx.